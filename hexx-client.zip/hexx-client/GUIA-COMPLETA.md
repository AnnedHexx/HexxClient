# ⚡ HEXX CLIENT - Guía Completa de Instalación

**Sistema de actualizaciones remotas para Minecraft Bedrock**

---

## 📦 CONTENIDO DEL PAQUETE

Este paquete incluye 3 carpetas:

1. **`launcher/`** - El launcher que distribuyes a los usuarios
2. **`panel-admin/`** - Panel web para editar la configuración
3. **`config-repo/`** - Archivos para subir a GitHub

---

## 🚀 PARTE 1: CONFIGURAR GITHUB (Una sola vez)

### Paso 1: Crear repositorio en GitHub

1. Ve a https://github.com y crea una cuenta (si no tienes)
2. Haz clic en el botón verde **"New"** (crear repositorio)
3. Nombre del repositorio: `hexx-config` (o el que quieras)
4. Marca como **"Public"** (importante para que sea accesible)
5. Haz clic en **"Create repository"**

### Paso 2: Subir archivos al repositorio

**Opción A: Subir desde la web (más fácil)**

1. En tu repositorio recién creado, haz clic en **"uploading an existing file"**
2. Arrastra el archivo `config.json` de la carpeta `config-repo/`
3. Crea una carpeta llamada `assets/` haciendo clic en "Create new file"
4. Escribe: `assets/background.png` y sube la imagen
5. Haz clic en **"Commit changes"**

**Opción B: Usando GitHub Desktop (recomendado)**

1. Descarga GitHub Desktop desde: https://desktop.github.com/
2. Clona tu repositorio
3. Copia todos los archivos de `config-repo/` a la carpeta clonada
4. Haz commit y push

### Paso 3: Obtener la URL del config.json

1. En GitHub, abre el archivo `config.json`
2. Haz clic en el botón **"Raw"**
3. Copia la URL que aparece (algo como):
   ```
   https://raw.githubusercontent.com/TU-USUARIO/hexx-config/main/config.json
   ```

### Paso 4: Configurar el launcher

1. Abre `launcher/index.html` con Notepad
2. Busca la línea 244 que dice:
   ```javascript
   const CONFIG_URL = 'https://raw.githubusercontent.com/TU-USUARIO/hexx-config/main/config.json';
   ```
3. Reemplaza `TU-USUARIO` con tu nombre de usuario de GitHub
4. Guarda el archivo

---

## 🎮 PARTE 2: DISTRIBUIR EL LAUNCHER

### Opción A: Distribuir como carpeta (más fácil)

1. Comprime toda la carpeta `launcher/` en un ZIP
2. Súbelo a tu sitio web, Discord, Google Drive, etc.
3. Los usuarios descargan el ZIP
4. Extraen la carpeta
5. Ejecutan `INSTALAR.bat`
6. ¡Listo!

### Opción B: Crear un .exe único (profesional)

1. Descarga Enigma Virtual Box: https://enigmaprotector.com/en/downloads.html
2. Primero ejecuta `INSTALAR.bat` para instalar NW.js
3. Abre Enigma Virtual Box
4. Input File: `nw.exe`
5. Output File: `Hexx Client.exe`
6. Add Folder: Agrega toda la carpeta con todos los archivos
7. Process
8. Distribuye el `Hexx Client.exe` único

---

## ⚙️ PARTE 3: PANEL DE ADMINISTRACIÓN

### Usar el panel web:

1. Abre `panel-admin/admin.html` en tu navegador
2. Edita lo que quieras:
   - Servidores (nombre, IP, puerto, icono, color)
   - Banner superior (mensaje, título, colores)
   - Tema visual (colores del launcher)
   - Versión del launcher
3. Haz clic en **"💾 Generar config.json"**
4. Copia el código JSON generado
5. Ve a tu repositorio en GitHub
6. Edita el archivo `config.json`
7. Pega el nuevo código
8. Haz clic en **"Commit changes"**

**¡Los cambios se reflejarán automáticamente en todos los launchers!**

---

## 🔄 CÓMO FUNCIONAN LAS ACTUALIZACIONES

```
Usuario abre Hexx Client
         ↓
Lee: github.com/TU-USUARIO/hexx-config/config.json
         ↓
Carga: Servidores, colores, banner actualizados
         ↓
Usuario ve: Los cambios más recientes
```

**Ventajas:**
- ✅ Sin descargas para los usuarios
- ✅ Actualizas desde el panel web
- ✅ Cambios instantáneos
- ✅ Control total

---

## 📝 QUÉ PUEDES ACTUALIZAR REMOTAMENTE

✅ **Servidores:**
- Añadir/quitar servidores
- Cambiar IPs y puertos
- Modificar nombres y descripciones
- Cambiar íconos y colores
- Actualizar contador de jugadores

✅ **Banner superior:**
- Activar/desactivar
- Cambiar mensaje
- Modificar título
- Cambiar ícono

✅ **Tema visual:**
- Colores del botón JUGAR
- Colores del banner
- Logo del launcher
- Fondo (si subes nueva imagen a GitHub)

✅ **Control de versiones:**
- Forzar actualización del launcher
- Versión mínima requerida

---

## 🎨 PERSONALIZACIÓN AVANZADA

### Cambiar el fondo:

1. Sube tu imagen a GitHub en `assets/background.png`
2. En el panel de admin, actualiza la URL del fondo
3. Genera nuevo config.json
4. Súbelo a GitHub

### Cambiar el logo:

1. En el panel de admin, cambia "Logo Emoji"
2. Puedes usar cualquier emoji: ⚡ 🔥 💎 ⭐ 🎮

### Añadir servidores:

1. Panel de admin → "➕ Agregar Servidor"
2. Llena los datos
3. Genera config.json
4. Sube a GitHub

---

## ❗ SOLUCIÓN DE PROBLEMAS

### El launcher no carga la configuración

- **Verifica la URL** en `index.html` línea 244
- Asegúrate de que el repositorio sea **Public**
- Comprueba que el archivo se llame exactamente `config.json`

### Los cambios no se reflejan

- GitHub puede cachear por unos minutos
- Cierra y abre el launcher de nuevo
- El launcher añade `?t=timestamp` para evitar caché

### El instalador no funciona

- Verifica conexión a internet
- Ejecuta como administrador
- Desactiva temporalmente el antivirus

### Error de versión mínima

- Actualiza el campo `minVersion` en config.json
- Los usuarios con versión antigua verán un mensaje
- Distribuye nueva versión del launcher

---

## 🎯 FLUJO DE TRABAJO RECOMENDADO

1. **Instalación inicial** (una vez):
   - Crea repositorio en GitHub
   - Configura la URL en el launcher
   - Distribuye el launcher a usuarios

2. **Actualizaciones diarias** (cuando quieras):
   - Abre panel de admin
   - Edita lo que necesites
   - Genera config.json
   - Súbelo a GitHub
   - ¡Listo! Todos ven los cambios

3. **Actualizaciones del launcher** (raramente):
   - Solo cuando cambies funcionalidades
   - Los usuarios descargan nueva versión
   - O usa sistema de auto-actualización

---

## 📊 ESTRUCTURA DE ARCHIVOS

```
hexx-client/
│
├── launcher/              # Distribuyes ESTA carpeta
│   ├── index.html        # Launcher principal
│   ├── background.png    # Fondo local (respaldo)
│   ├── package.json      # Configuración NW.js
│   └── INSTALAR.bat      # Instalador automático
│
├── panel-admin/          # Para TI (no distribuir)
│   └── admin.html        # Panel de configuración
│
└── config-repo/          # Subes ESTO a GitHub
    ├── config.json       # Configuración remota
    └── assets/
        └── background.png
```

---

## 🔐 SEGURIDAD Y MEJORES PRÁCTICAS

✅ **Haz commits descriptivos** en GitHub
✅ **Prueba los cambios** antes de subirlos
✅ **Mantén respaldos** del config.json
✅ **No compartas** tu panel de admin
✅ **Usa versiones** para control de cambios

---

## 🆘 SOPORTE Y RECURSOS

- **GitHub Docs:** https://docs.github.com
- **NW.js Docs:** https://nwjs.io/
- **JSON Validator:** https://jsonlint.com/ (para verificar config.json)

---

## 🎉 ¡FELICIDADES!

Ahora tienes un launcher profesional con actualizaciones remotas.

**Recuerda:**
- Los usuarios descargan el launcher **una vez**
- Tú actualizas todo desde el **panel web**
- Los cambios son **instantáneos**
- Sin requerir nuevas descargas

**¡Disfruta de Hexx Client! ⚡**
